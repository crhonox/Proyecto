# Calendario by icodeart
Calendario con eventos en php y mysql diseñado en Bootstrap.

#Uso
Modificar el archivo config.php con la informacion de tu base de dato e importar el archivo sql a tu base de datos.

#Funcionamiento
https://www.youtube.com/watch?v=fIiNIcID7ik
