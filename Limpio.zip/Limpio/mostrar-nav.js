$('#mostrar-nav').on('click',function(){
    $('nav').toggleClass('mostrar');

})
