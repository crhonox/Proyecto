// save-form.php
<?php print_r($_POST); ?>
